// AS5_244101064.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define splitting_factor 0.03
#define row_length 12
#define col_length 6340
#define csv_column 12
#define csv_rows 6340
#define k 8

float universe[csv_rows][csv_column];
float centroid[8][csv_column];
int cluster[csv_rows] = {0};
int cluster_size[8] = {0};
double lbg_centroid[csv_column] = {0.0};

float tokura_distance(int index, float point[csv_column]) {
    float dist = 0;
    float tokura_weights[csv_column] = {1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};
    for (int i = 0; i < csv_column; i++) {
        float diff = point[i] - centroid[index][i];
        dist += tokura_weights[i] * (diff * diff);
    }
    return dist;
}

void update_centroids(int x) {
    // Dynamically allocate memory for updated centroids
    float** updated_centroids = (float**)malloc(x * sizeof(float*));
    for (int i = 0; i < x; i++) {
        updated_centroids[i] = (float*)calloc(csv_column, sizeof(float));
    }

    for (int cent = 0; cent < x; cent++) {
        for (int i = 0; i < csv_column; i++) {
            int count = 0;
            for (int j = 0; j < csv_rows; j++) {
                if (cluster[j] == (cent + 1)) {
                    updated_centroids[cent][i] += universe[j][i];
                    count++;
                }
            }
            if (count != 0) {
                updated_centroids[cent][i] /= count; // average it
                centroid[cent][i] = updated_centroids[cent][i];
            }
        }
    }

    // Free dynamically allocated memory
    for (int i = 0; i < x; i++) {
        free(updated_centroids[i]);
    }
    free(updated_centroids);

    // Resetting cluster
    for (int c = 0; c < csv_rows; c++) {
        cluster[c] = 0;
    }
}

float distortion_calculator(int x) {
    float* avg_distortion = (float*)calloc(x, sizeof(float));
    float distortion = 0.0;
    for (int c = 0; c < x; c++) {
        float dist = 0.0;
        for (int u = 0; u < csv_rows; u++) {
            if (cluster[u] == (c + 1)) {
                dist += tokura_distance(c, universe[u]);
            }
        }
        avg_distortion[c] = dist;
        }

    distortion = 0.0;
    for (int d = 0; d < x; d++) {
        distortion += avg_distortion[d];
    }
    distortion /= csv_rows;
    // Free dynamically allocated memory
    free(avg_distortion);
    return distortion;
}

void read_csv_to_float_array(const char* filename) {
    FILE* file = fopen(filename, "r"); // Open the CSV file
    if (file == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char row[1024];
    int row_index = 0;
    while (fgets(row, sizeof(row), file) && row_index < csv_rows) {
        char* token = strtok(row, ",");
        int col_index = 0;
        while (token && col_index < csv_column) {
            universe[row_index][col_index] = atof(token);
            token = strtok(NULL, ",");
            col_index++;
        }
        row_index++;
    }

    fclose(file);  // Close the file
}

void split_centroid(int x) {

    for (int cent = 0; cent <  x; cent++) {
        for (int i = 0; i < csv_column; i++) {
            centroid[cent + x ][i] = centroid[cent][i] * (1 + splitting_factor);
            centroid[cent][i] = centroid[cent][i] * (1 - splitting_factor);
        }
    }

    printf("For K= %d\n\n", x*2);

}
void initial_centroid(){
    for (int i = 0; i < csv_column; i++) {
        for (int j = 0; j < csv_rows; j++) {
            lbg_centroid[i] += universe[j][i];
        }
        lbg_centroid[i] /= csv_rows;
        centroid[0][i] = lbg_centroid[i];
    }

}
void lbg_kmeans() {

	int current_codebook_size = 1;

    initial_centroid();
    
    while (current_codebook_size < k) {
        split_centroid(current_codebook_size);
		current_codebook_size *= 2;

		float prev_distortion = 0.0;
		int iterations = 0;
		
		float distortion = 99999;
        while (fabs(distortion - prev_distortion) > 0.00001) {
            if (iterations != 0)
                prev_distortion = distortion;

            // Dynamically allocate memory for dist
            float* dist = (float*)malloc(current_codebook_size * sizeof(float));

            for (int i = 0; i < csv_rows; i++) {
                for (int j = 0; j < current_codebook_size; j++) {
                    dist[j] = tokura_distance(j, universe[i]);
                }

                float min = 99999999;
                int cluster_index = -1;

                for (int index = 0; index < current_codebook_size; ++index) {
                    if (dist[index] < min) {
                        cluster_index = (index + 1); // check working
                        min = dist[index];
                    }
                }
                cluster[i] = cluster_index;
            }

            for (int index = 0; index < current_codebook_size; index++) {
                cluster_size[index] = 0.0;
                for (int size = 0; size < csv_rows; size++) {
                    if (cluster[size] == (index + 1)) {
                        cluster_size[index] += 1;
                    }
                }
            }

            // Calculating distortion
            distortion = distortion_calculator(current_codebook_size);
            iterations++;
            printf("For codebook size %d ====> iteration : %d distortion is : %f\n", current_codebook_size, iterations, distortion);
            update_centroids(current_codebook_size);

            // Free dynamically allocated memory for dist
            free(dist);
        }
        printf("\n");
    }
}

void write_csv() {
    // Open the file for writing
    FILE *fp = fopen("Final_codebook.csv", "w");

    if (fp == NULL) {
        printf("Error: Could not open file for writing\n");
        return;
    }

    for (int i = 0; i < k; i++) {
        for (int j = 0; j < csv_column; j++) {
            fprintf(fp, "%lf", centroid[i][j]);
            if (j < csv_column - 1) {
                fprintf(fp, ",");  // Separate elements with a comma
            }
        }
        fprintf(fp, "\n");  // Move to the next line after each row
    }

    // Close the file
    fclose(fp);
    printf("Codebook written to successfully.\n");
}


int main() {
    read_csv_to_float_array("Universe.csv");
    lbg_kmeans();
	write_csv();
    return 0;
}
